function Blop(c, beingId) {
  this.x = mouseX; //mouseX //touchX
  this.y = mouseY; //mouseY //touchY
  this.fixedX = mouseX;
  this.fixedY = mouseY;
  this.diameter = int(random(16, 25)); //les nombres décimaux finissent par se décaler au fil du temps, donc mieux de s'en tenir aux entiers ou 0.5 apparement
  this.speed = int(random(1));
  this.colour = c;
  this.beingId = beingId;
  this.goesUp = false;
  this.breathUp = false;
  

  this.getsBigger = function() {
    if(this.diameter < 15 || this.diameter > 30 ) {
      this.goesUp = !this.goesUp;
    }
    
    if (this.goesUp == true){
      this.diameter += 0.2*this.speed;
    }else{
      this.diameter -= 0.2*this.speed;
    }
  }
  
  this.display = function() {
    fill(this.colour);
    noStroke();
    ellipse(this.x, this.y, this.diameter, this.diameter);
    stroke(0);
    }
    
  this.breath = function() {
    if(this.y < this.fixedY - 10 || this.y > this.fixedY + 5 ) {
      this.breathUp = !this.breathUp;
    }
    
    if (this.breathUp == true){
      this.y += 0.3;
    }else{
      this.y -= 0.3;
    }
  }
  
  this.move = function() {
    this.x += 0.2;
  }
}
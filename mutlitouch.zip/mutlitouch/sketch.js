//// WHEN SOMEONE STARTS PLACING FINGERS ON THE SCREEN (=ACTIVATED IN DEMO WITH A KEYPRESS), A NEW BEING IS CREATED (ARRAY OF BLOPS)
//// WHEN THEY TAKE THEIR FINGERS OFF, THIS BEING LIVES ITS LIFE. 
//// IF THEY PUT THEIR FINGERS BACK, A NEW BEING (= NEW ELEMENT IN THE BEING ARRAY) IS CREATED.

var being;
var beings = [];
var beingId = 0;

var circle;
var clicked = false;

var numberCir = 0;

var newBeing = true;

var ready = false;

function setup() {
  createCanvas(710, 400);
  colorMode(RGB);
  noFill();
  frameRate(30);
}

function draw() {
  background(50, 89, 100);
  
  ///// CREATE A NEW BEING EVERY TIME A KEY IS PRESSED
  if(newBeing == true){  
   /* being = new Being(beingId, color(random(255),random(255),random(255), 20));*/
    being = new Being(beingId, color(255,255,255, 20));
    beings.push(being);
    beingId++;
    newBeing = false;
  }

  for(var i = 0; i < beings.length; i++){
    beings[i].fixedLines();
    beings[i].move();

    beings[i].display();
  //  beings[i].randomLines();
    
    
    //// TO TEST WHEN NEW BEING IS CREATED: DISPLAYS A NEW RECTANGLE
    // beings[i].moveRect();
    // beings[i].displayRect();
  }
  
  //print("number of beings: " + beings.length);

}

function mousePressed(){
  //// CREATES A BLOB EVERY TIME A KEY IS PRESSED
  //// USING A FOR LOOP WOULD CREATE AS MANY BLOPS AS BEINGS FOR EACH CLICK, SO WOULD NOT WORK AS INTENDED
  if(beings.length > 0){
    beings[beings.length-1].createBlops();
  }
  clicked = true;
  
      for(var i = 0; i < beings.length; i++){
      beings[i].keypressed();
    }

}

function keyPressed(){
  //// CREATES A NEW BEING EVERY TIME A KEY IS PRESSED
   newBeing = true;
  for(var i = 0; i < beings.length; i++){
    beings[i].ready = true;
  }
}


function Being(beingId, c) {
  this.x = random(width);
  this.y = random(height);
  this.diameter = int(random(10, 30));
  this.speed = 1;
  this.blops = [];
  this.colour = c;
  this.timer1 = millis();
  this.timer2 = millis();
  this.randomPointA = 0;
  this.randomPointB = 0;
  this.randomPointC = 0;
  this.randomPointD = 0;
  this.distancePoints = [];
  this.id = 0;
  this.beingId = beingId;
  this.ready = false;
  
  this.createBlops = function(){
    //// CREATES A NEW BLOP WHEN MOUSE PRESSED
    this.blop = new Blop(this.colour, this.beingId);
    this.blops.push(this.blop);
    //print(this.blop.beingId);
    //print(this.blop);
  }
  
  this.display = function() {
    print(this.ready);
    for(var i = 0; i < this.blops.length; i++){
      
      this.blops[i].breath();
      this.blops[i].getsBigger();
      if (this.ready == false) {
        this.blops[i].display();
      }
    }
  }
  
  this.move = function() {
    for(var i = 0; i < this.blops.length; i++){
      if (this.ready == true) {
         
         this.blops[i].move();
      }
    }
  }

  this.moveRect = function() {
    // MOVES THE RECT (for tests)
    this.x += random(-this.speed, this.speed);
    this.y += random(-this.speed, this.speed);
  }

  this.displayRect = function() {
    // PRINTS A RECTANGLE EVERY TIME A NEW BEING IS CREATED (for tests)
    rect(this.x, this.y, this.diameter, this.diameter);
  }
  
  this.fixedLines = function() {
    if(this.blops.length>3){
      // Draw a line between two closest blops
      //line(this.distancePoints.closestPoint1.x,this.distancePoints.closestPoint1.y,this.distancePoints.closestPoint2.x,this.distancePoints.closestPoint2.y);
      for(var i = 0; i < this.blops.length; i++){
        stroke(255);
/*        line(this.distancePoints.closestPoint1.x,this.distancePoints.closestPoint1.y,this.blops[i].x, this.blops[i].y);
        line(this.distancePoints.closestPoint2.x,this.distancePoints.closestPoint2.y,this.blops[i].x, this.blops[i].y);*/
        line(this.blops[0].x, this.blops[0].y, this.blops[i].x, this.blops[i].y);
        line(this.blops[1].x, this.blops[1].y, this.blops[i].x, this.blops[i].y);
        line(this.blops[2].x, this.blops[2].y, this.blops[i].x, this.blops[i].y);
       // line(this.blops[3].x, this.blops[3].y, this.blops[i].x, this.blops[i].y);
      }
    }
  }

  
  
  this.randomLines = function() {
    if(millis() > this.timer1 + 200){
      this.randomPointA = int(0); //random(this.blops.length-1)
      this.randomPointB = int(1);
      this.timer = millis();
    }
    
    if(millis() > this.timer2 + 250){
      this.randomPointC = int(random(this.blops.length));
      this.randomPointD = int(random(this.blops.length));
      this.timer = millis();
    }
     if(this.blops.length>1){// we need at least 2 points to start calculating distances
      // line(this.distancePoints.closestPoint1.x, this.distancePoints.closestPoint1.y,this.blops[this.randomPointA].x, this.blops[this.randomPointA].y)
      // line(this.distancePoints.closestPoint2.x,this.distancePoints.closestPoint2.y,this.blops[this.randomPointB].x, this.blops[this.randomPointB].y)
     }

    if (this.blops.length > 1){
      line(this.blops[this.randomPointC].x, this.blops[this.randomPointC].y,this.blops[this.randomPointD].x, this.blops[this.randomPointD].y);
    }
  }
  
  this.keypressed = function() {//SHOULDNT BE calculated in distancepoints because it's for each being. So it's probably here
    if(this.blops.length>1){// we need at least 2 points to start calculating distances
      this.distancePoints = new DistancePoints();
      var arrayDistancePoints = this.distancePoints.calculDistances(this.blops);
      var arraySorted = this.distancePoints.sortByDistance(arrayDistancePoints);
      this.distancePoints.calculs(arraySorted, this.blops);
    }
  }
}
